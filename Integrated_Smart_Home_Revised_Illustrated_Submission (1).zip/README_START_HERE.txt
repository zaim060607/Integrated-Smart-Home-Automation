INTEGRATED SMART HOME AUTOMATION & SECURITY ECOSYSTEM
REVISED REQUIREMENT-ALIGNED SUBMISSION | 24 NOVEMBER 2026

WHAT IS ACTUALLY VERIFIED
- User demonstrated Arduino Uno Wokwi simulation: temperature ON/OFF, LDR ON/OFF,
  PIR motion event, door-open event, and Normal mode.
- Original screenshots are preserved. Cropped images annotate input+output side-by-side.
- User additionally reported buzzer, armed LEDs and servo auto-close working.

WHERE TO FIND REQUIRED DELIVERABLES
1. 01_Firmware/Verified_Arduino_Uno_Wokwi.ino (verified simulation firmware)
   01_Firmware/ESP8266_NodeMCU_Hardware_Target_UNTESTED.ino (target reference, UNTESTED)
2. 02_Circuits/ESP8266_NodeMCU_Target_Schematic.png (proposed circuit pin-map)
   02_Circuits/Verified_Wokwi_Arduino_Uno_diagram.json (editable tested circuit)
3. 03_Architecture/System_Flowchart.png
4. 04_Report/Illustrated_Technical_Report_12_Pages.pdf
5. 05_Annotated_Evidence/ (7 evidence images with output captions)
   06_Original_Screenshots/ (all original screenshot evidence)

IMPORTANT / STILL NOT VERIFIED
- Original brief calls for ESP8266 NodeMCU, matrix, thermistor.
- Verified screens show Arduino Uno, individual LEDs, NTC thermistor.
- ESP8266 + MAX7219 schematic and source are offered as a design target ONLY;
  they were not simulated or physically validated.
- ESP8266 build needs ADS1115, PCF8574, MAX7219, level/power considerations.
- Schematic is a circuit-design wiring blueprint, not a Fritzing breadboard capture.

Wokwi original: https://wokwi.com/projects/481509571766192129

Do NOT represent proposed hardware outputs as validated observations.
