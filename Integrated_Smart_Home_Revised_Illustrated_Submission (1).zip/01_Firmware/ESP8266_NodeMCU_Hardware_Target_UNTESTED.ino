/* ESP8266 NodeMCU hardware-target reference firmware.
   NOT YET COMPILED OR VALIDATED ON PHYSICAL ESP8266.
   Added hardware to meet original brief with sufficient I/O:
   ADS1115 analog ADC, PCF8574 I/O expander, MAX7219 LED matrix.
   Libraries: ESP8266 Arduino core; Adafruit ADS1X15;
              Adafruit BusIO; LedControl; Servo (ESP8266 supported).
*/
#include <Arduino.h>
#include <Wire.h>
#include <Servo.h>
#include <Adafruit_ADS1X15.h>
#include <LedControl.h>
#include <math.h>

// GPIO chosen to avoid most ESP8266 boot-strap conflicts.
const uint8_t PIR_PIN = D0;    // GPIO16
const uint8_t SERVO_PIN = D4;  // GPIO2; servo signal must not pull this low on boot
const uint8_t MATRIX_DIN = D5, MATRIX_CLK = D6, MATRIX_CS = D7;
const uint8_t BUZZER_PIN = D8; // GPIO15, use transistor driver with boot-safe LOW
const uint8_t PCF_ADDRESS = 0x20;
// PCF8574 P0=Doorbell, P1=Mode; P2..P7 six LED indicators (active LOW).
enum { BELL_P=0, MODE_P=1, COOL_P=2, LIGHT_P=3, ALERT_P=4,
       WELCOME_P=5, NORMAL_P=6, ARMED_P=7 };
Adafruit_ADS1115 ads;
LedControl matrix(MATRIX_DIN, MATRIX_CLK, MATRIX_CS, 1);
Servo door;
bool armed=false, cooling=false, doorOpen=false, motion=false, dark=false;
bool bellLast=true, modeLast=true, bellStable=true, modeStable=true;
unsigned long bellChanged=0, modeChanged=0, openedAt=0;
unsigned long sampledAt=0, reportedAt=0;
float tempC=24.0, ldrVolts=0.0;

uint8_t readPCF() {
  Wire.requestFrom(PCF_ADDRESS, (uint8_t)1);
  return Wire.available() ? Wire.read() : 0xff;
}
void writeIndicators(bool alertPhase) {
  uint8_t bits=0xff; // P0,P1 remain high to permit button input
  if(cooling) bits &= ~(1 << COOL_P);
  if(dark) bits &= ~(1 << LIGHT_P);
  if(motion && (!armed || alertPhase)) bits &= ~(1 << ALERT_P);
  if(doorOpen) bits &= ~(1 << WELCOME_P);
  if(!armed) bits &= ~(1 << NORMAL_P);
  if(armed) bits &= ~(1 << ARMED_P);
  Wire.beginTransmission(PCF_ADDRESS);
  Wire.write(bits);
  Wire.endTransmission();
}
void matrixIcons() {
  // Non-blocking status indicators on 8x8 LED matrix:
  // left=climate, center=light, right=armed; lower row=PIR detected.
  matrix.clearDisplay(0);
  if(cooling) for(int row=1; row<=3; row++) matrix.setLed(0,row,1,true);
  if(dark) for(int row=1; row<=3; row++) matrix.setLed(0,row,4,true);
  if(armed) for(int row=1; row<=3; row++) matrix.setLed(0,row,7,true);
  if(motion) for(int col=1; col<=7; col++) matrix.setLed(0,6,col,true);
}
void setup() {
  Serial.begin(9600);
  pinMode(PIR_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT); digitalWrite(BUZZER_PIN, LOW);
  Wire.begin(D2, D1); // SDA=D2 GPIO4, SCL=D1 GPIO5
  Wire.beginTransmission(PCF_ADDRESS); Wire.write(0xff); Wire.endTransmission();
  if(!ads.begin(0x48)) Serial.println("ERROR: ADS1115 not detected");
  ads.setGain(GAIN_ONE); // +/-4.096V, valid for 0..3.3V
  matrix.shutdown(0,false); matrix.setIntensity(0,4); matrix.clearDisplay(0);
  door.attach(SERVO_PIN); door.write(0);
  Serial.println("ESP8266 TARGET INITIALIZED - HARDWARE VALIDATION REQUIRED");
}
void loop() {
  const unsigned long now=millis();
  uint8_t buttons=readPCF();
  bool b=(buttons & (1 << BELL_P)) != 0;
  bool m=(buttons & (1 << MODE_P)) != 0;
  if(b != bellLast) bellChanged=now;
  if(m != modeLast) modeChanged=now;
  if(now-bellChanged>40 && b != bellStable) {
    bellStable=b;
    if(!b){ doorOpen=true; openedAt=now; door.write(90); Serial.println("DOOR OPEN"); }
  }
  if(now-modeChanged>40 && m != modeStable) {
    modeStable=m;
    if(!m){ armed=!armed; Serial.println(armed?"SECURITY ARMED":"NORMAL MODE"); }
  }
  bellLast=b; modeLast=m;
  if(doorOpen && now-openedAt>=5000){ doorOpen=false; door.write(0); Serial.println("DOOR CLOSED"); }

  if(now-sampledAt>=200) {
    sampledAt=now;
    float v=ads.computeVolts(ads.readADC_SingleEnded(0));
    // 10k fixed resistor to 3.3V; 10k NTC thermistor to GND, B=3950.
    if(v>0.02 && v<3.28) {
      float r=10000.0*v/(3.3-v);
      tempC=1.0/(1.0/298.15 + log(r/10000.0)/3950.0)-273.15;
    }
    if(tempC>=30.0) cooling=true;
    else if(tempC<=28.0) cooling=false;
    ldrVolts=ads.computeVolts(ads.readADC_SingleEnded(1));
    // LDR to GND and fixed 10k to 3.3V => higher voltage when dark.
    dark=ldrVolts>1.9; // CALIBRATE ON ACTUAL HARDWARE
    motion=digitalRead(PIR_PIN)==HIGH;
  }
  bool flash=((now/250)%2)==0;
  writeIndicators(flash);
  // Refresh matrix only on a moderate, non-blocking interval.
  static unsigned long lastMatrix=0;
  if(now-lastMatrix>=300){lastMatrix=now;matrixIcons();}
  if((armed && motion && flash) || (cooling && now%4000<150))
    tone(BUZZER_PIN, armed && motion ? 1400 : 900);
  else noTone(BUZZER_PIN);
  if(now-reportedAt>=1000){
    reportedAt=now;
    Serial.print("Temp C: ");Serial.print(tempC,1);
    Serial.print(" | LDR V: ");Serial.print(ldrVolts,2);
    Serial.print(" | PIR: ");Serial.print(motion?"MOTION":"clear");
    Serial.print(" | Cooling: ");Serial.print(cooling?"ON":"OFF");
    Serial.print(" | Light: ");Serial.print(dark?"ON":"OFF");
    Serial.print(" | Mode: ");Serial.println(armed?"ARMED":"NORMAL");
  }
}
